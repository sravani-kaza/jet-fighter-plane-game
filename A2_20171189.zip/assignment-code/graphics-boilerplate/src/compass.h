#include "main.h"
#include "circle.h"

#ifndef Compass_H
#define Compass_H


class Compass {
public:
    Compass() {}
    Compass(float x, float y,float z, color_t color,float val);
    glm::vec3 position;
    float rotation_x;
    float rotation_y;
    float rotation_z;
    Circle C;
    int present;
    void draw(glm::mat4 VP);
    void set_position(float x, float y,float z);
    void tick(); 
    float angle;


private:
    VAO *object;
    VAO *dir;
};

#endif // Compass_H
