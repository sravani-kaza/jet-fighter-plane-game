#include "compass.h"
#include "main.h"
#include "circle.h"

Compass::Compass(float x, float y, float z,color_t color,float val) {
    this->position = glm::vec3(x, y+0.001, z);
    this->rotation_x = 0;
    this->rotation_y = val;
    this->rotation_z = -90;
    this->present = 0;
    color = {255,255,255};
    this->C = Circle(x,y,z,color,2);
    GLfloat g_vertex_buffer_dir[]={
        0,0,-1,
        -0.4,0,-0.8,
        0.4,0,-0.8,

        0.3,0,-0.8,
        -0.3,0,1,
        -0.3,0,-0.8,

        0.3,0,-0.8,
        -0.3,0,1,
        0.3,0,1,

    };
    GLfloat g_vertex_buffer_arrows[]={
        0,0,-1,
        -0.4,0,-0.9,
        0.4,0,-0.9,

        0.3,0,-0.9,
        -0.3,0,1,
        -0.3,0,-0.9,

        0.3,0,-0.9,
        -0.3,0,1,
        0.3,0,1,

    };
    // Our vertices. Three consecutive floats give a 3D vertex; Three consecutive vertices give a triangle.
    // A cube has 6 faces with 2 triangles each, so this makes 6*2=12 triangles, and 12*3 vertices
    color = {0, 255, 0 };
    this->object = create3DObject(GL_TRIANGLES, 3*3, g_vertex_buffer_arrows, color, GL_FILL);
    color = {255,0,0};
    this->dir = create3DObject(GL_TRIANGLES, 3*3, g_vertex_buffer_dir, color, GL_FILL);
    
}   

void Compass::draw(glm::mat4 VP) {
    this->C.position.x = this->position.x;
    this->C.position.y = this->position.y;
    this->C.position.z = this->position.z;

    Matrices.model = glm::mat4(1.0f);
    glm::mat4 translate = glm::translate (this->position);    // glTranslatef
    glm::mat4 rotate    = glm::rotate((float) (this->rotation_z * M_PI / 180.0f), glm::vec3(0, 0, 1));
    //rotate    *= glm::rotate((float) (this->rotation_x * M_PI / 180.0f), glm::vec3(1, 0, 0));
    rotate    *= glm::rotate((float) (this->rotation_x * M_PI / 180.0f), glm::vec3(1, 0, 0));
    rotate    *= glm::rotate((float) (this->rotation_y * M_PI / 180.0f), glm::vec3(0, 1, 0));
    // No need as coords centered at 0, 0, 0 of cube arouund which we waant to rotate
    // rotate          = rotate * glm::translate(glm::vec3(0, -0.6, 0));
    glm::mat4 MVP = VP * translate;
    glUniformMatrix4fv(Matrices.MatrixID, 1, GL_FALSE, &MVP[0][0]);
    draw3DObject(this->object);
    glm::mat4 rotate1    = glm::rotate((float) (90 * M_PI / 180.0f), glm::vec3(0, 1, 0));
    glm::mat4 MVP1 = VP * translate * rotate1;
    glUniformMatrix4fv(Matrices.MatrixID, 1, GL_FALSE, &MVP1[0][0]);
    draw3DObject(this->object);
    Matrices.model *= (translate * rotate);
    MVP = VP * Matrices.model;
    glUniformMatrix4fv(Matrices.MatrixID, 1, GL_FALSE, &MVP[0][0]);
    draw3DObject(this->dir);
    this->C.draw(VP);
}

void Compass::set_position(float x, float y,float z) {
    this->position = glm::vec3(x, y, z);
}

void Compass::tick() {
    //   this->rotation += speed;
    // this->position.x -= speed;
    // this->position.y -= speed;
}

