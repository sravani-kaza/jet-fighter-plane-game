#include "parachute.h"
#include "main.h"
#include "circlexz.h"

Parachute::Parachute(float x, float y, float z,color_t color) {
    this->position = glm::vec3(x, y, z);
    this->rotation_x = 0;
    this->rotation_y = 0;
    this->rotation_z = 0;
    this->r = 1;
    this->f = 1;
    this->initx = x;
    this->inity = y;
    this->initz = z;
    this->present = 1;
    float prev_y=0.0f;
    float r=0.02f;
    for(int i=0;i<120;i++)
    {
        if(i%2)
            color = {0,0,255};
        else
            color = {255,255,0};
        this->C[i] = Circlexz(x,y+prev_y,z,color,r,0.2);
        prev_y = r;
        r += 0.01;
    }
    r -= 0.02;
    for(int i=120;i<200;i++)
    {
        if(i%2)
            color = {0,0,255};
        else
            color = {255,255,0};
        this->C[i] = Circlexz(x,y+prev_y,z,color,r,0.1);
        r -= 0.015;
        prev_y = r;
    }
    GLfloat g_vertex_buffer_cube[]={
        0.5,-4.5,0.5,
        -0.5,-4.5,-0.5,
        0.5,-4.5,-0.5,

        0.5,-4.5,0.5,
        -0.5,-4.5,-0.5,
        -0.5,-4.5,0.5,    //face1

        0.5,-3,0.5,
        -0.5,-3,-0.5,
        0.5,-3,-0.5,

        0.5,-3,0.5,
        -0.5,-3,-0.5,
        -0.5,-3,0.5,    //face2

        0.5,-4.5,-0.5,
        0.5,-3,0.5,
        0.5,-3,-0.5,

        0.5,-4.5,-0.5,
        0.5,-3,0.5,
        0.5,-4.5,0.5,

        -0.5,-4.5,-0.5,
        -0.5,-3,0.5,
        -0.5,-3,-0.5,  //face3

        -0.5,-4.5,-0.5,
        -0.5,-3,0.5,
        -0.5,-4.5,0.5,    //face4

        -0.5,-4.5,0.5,
        0.5,-3,-0.5,
        0.5,-4.5,0.5,

        -0.5,-4.5,0.5,
        0.5,-3,-0.5,
        -0.5,-3,0.5,    //face5

        -0.5,-4.5,-0.5,
        0.5,-3,0.5,
        0.5,-4.5,-0.5,

        -0.5,-4.5,-0.5,
        0.5,-3,0.5,
        -0.5,-3,-0.5,    //face6


    };
    GLfloat g_vertex_buffer_lines[]={
        0,0,0,
        0.5,-3,-0.5,
        0,0,0,
        0.5,-3,0.5,
        0,0,0,
        -0.5,-3,0.5,
        0,0,0,
        -0.5,-3,-0.5,

    };
    // Our vertices. Three consecutive floats give a 3D vertex; Three consecutive vertices give a triangle.
    // A cube has 6 faces with 2 triangles each, so this makes 6*2=12 triangles, and 12*3 vertices
    color = {255, 255, 94 };
    this->cube = create3DObject(GL_TRIANGLES, 12*3, g_vertex_buffer_cube, color, GL_FILL);
    color = {255,0,0};
    this->lines = create3DObject(GL_LINES, 4*2, g_vertex_buffer_lines, color, GL_FILL);
        
}

void Parachute::draw(glm::mat4 VP) {
    this->parachute_box.x = this->position.x;
    this->parachute_box.y = this->position.y - 1.5;
    this->parachute_box.z = this->position.z;
    this->parachute_box.width = 2;
    this->parachute_box.height = 7;
    this->parachute_box.length = 2;
        
    float prev_y=0.0f;
    float r=0.02f;
    for(int i=0;i<120;i++)
    {
        this->C[i].position.x = this->position.x;
        this->C[i].position.y = this->position.y+prev_y;
        this->C[i].position.z = this->position.z;
        prev_y = r;
        r += 0.01;
    }
    r -= 0.02;
    for(int i=120;i<200;i++)
    {
        this->C[i].position.x = this->position.x;
        this->C[i].position.y = this->position.y+prev_y;
        this->C[i].position.z = this->position.z;
        r -= 0.015;
        prev_y = r;
    }
    Matrices.model = glm::mat4(1.0f);
    glm::mat4 translate = glm::translate (this->position);    // glTranslatef
    glm::mat4 rotate    = glm::rotate((float) (this->rotation_z * M_PI / 180.0f), glm::vec3(0, 0, 1));
    //rotate    *= glm::rotate((float) (this->rotation_x * M_PI / 180.0f), glm::vec3(1, 0, 0));
    rotate    *= glm::rotate((float) (this->rotation_x * M_PI / 180.0f), glm::vec3(1, 0, 0));
    rotate    *= glm::rotate((float) (this->rotation_y * M_PI / 180.0f), glm::vec3(0, 1, 0));
    // No need as coords centered at 0, 0, 0 of cube arouund which we waant to rotate
    // rotate          = rotate * glm::translate(glm::vec3(0, -0.6, 0));
    Matrices.model *= (translate * rotate);
    glm::mat4 MVP = VP * Matrices.model;
    glUniformMatrix4fv(Matrices.MatrixID, 1, GL_FALSE, &MVP[0][0]);
    draw3DObject(this->cube);
    draw3DObject(this->lines);
    for(int i=0;i<100;i++)
        this->C[i].draw(VP);
}

void Parachute::set_position(float x, float y,float z) {
    this->position = glm::vec3(x, y, z);
}

void Parachute::tick() {
    if(this->r == 1 && this->position.x >= this->initx + 5.0f)
    {
        this->r = 0;
        this->position.x -= 0.1f;
    }        
    else if(this->r == 1 && this->position.x < this->initx + 5.0f)
    {
        this->position.x += 0.1f;
    }
    else if(this->r == 0 && this->position.x <= this->initx - 5.0f )
    {
        this->r = 1;
        this->position.x += 0.1f;
    }
    else if(this->r == 0 && this->position.x > this->initx - 5.0f)
    {
        this->position.x -= 0.1f;
    }
    else 
    {
    }

    if(this->f == 1 && this->position.z <= this->initz - 4.0f)
    {
        this->f = 0;
        this->position.z += 0.05f;
    }        
    else if(this->f == 1 && this->position.z > this->initz - 4.0f)
    {
        this->position.z -= 0.05f;
    }
    else if(this->f == 0 && this->position.z >= this->initz + 4.0f )
    {
        this->f = 1;
        this->position.z -= 0.05f;
    }
    else if(this->f == 0 && this->position.z < this->initz + 4.0f)
    {
        this->position.z += 0.05f;
    }
}
    

