#include "main.h"
#include "circle.h"
#include "arrow.h"

#ifndef Island_H
#define Island_H


class Island {
public:
    Island() {}
    Island(float x, float y,float z, color_t color,int val);
    glm::vec3 position;
    float rotation;
    Circle C;
    void draw(glm::mat4 VP);
    void set_position(float x, float y,float z);
    void tick(); 
    Arrow arrow;
    int fuelup;
    bounding_box_t island_box;

private:
    VAO *prism;
    VAO *cube;
};

#endif // Island_H
