#include "enemy.h"
#include "main.h"
#include "circlexy.h"
#include "missile.h"

Enemy::Enemy(float x, float y, float z,color_t color) {
    this->position = glm::vec3(x, y, z);
    this->init_x = x;
    this->init_y = y;
    this->init_z = z;
    this->rotation_x = 0;
    this->rotation_y = 0;
    this->rotation_z = 0;
    this->r = 1;
    this->f = 1;
    this->present = 1;
    color = {255,255,255};
    this->C1 = Circlexy(x+1,y+1.3,z-0.45,color,0.1,0.0001);
    this->C2 = Circlexy(x+1,y+1.3,z-0.45,color,0.1,0.0001);
    color = {0,0,0};
    this->C3 = Circlexy(x+1,y+1.3,z-0.45,color,0.0025,0.0001);
    this->C4 = Circlexy(x+1,y+1.3,z-0.45,color,0.0025,0.0001);
    GLfloat g_vertex_buffer_cuboid[]={
        0.2,0.8,0.2,
        0.2,0,-0.2,
        0.2,0.8,-0.2,   //

        0.2,0.8,0.2,
        0.2,0,-0.2,
        0.2,0,0.2,    //face1

        -0.2,0.8,0.2,
        -0.2,0,-0.2,
        -0.2,0.8,-0.2,   //

        -0.2,0.8,0.2,
        -0.2,0,-0.2,
        -0.2,0,0.2,    //face2

        -0.2,0,0.2,
        0.2,0.8,0.2,
        0.2,0,0.2,    //

        -0.2,0,0.2,
        0.2,0.8,0.2,        
        -0.2,0.8,0.2,   //face3

        -0.2,0,-0.2,
        0.2,0.8,-0.2,
        0.2,0,-0.2,    //

        -0.2,0,-0.2,
        0.2,0.8,-0.2,        
        -0.2,0.8,-0.2,   //face4

    };
    GLfloat g_vertex_buffer_cube[]={
        0.4,1.6,0.4,
        0.4,0.9,-0.4,
        0.4,1.6,-0.4,   //

        0.4,1.6,0.4,
        0.4,0.9,-0.4,
        0.4,0.9,0.4,    //face1

        -0.4,1.6,0.4,
        -0.4,0.9,-0.4,
        -0.4,1.6,-0.4,   //

        -0.4,1.6,0.4,
        -0.4,0.9,-0.4,
        -0.4,0.9,0.4,    //face2

        -0.4,0.9,0.4,
        0.4,1.6,0.4,
        0.4,0.9,0.4,    //

        -0.4,0.9,0.4,
        0.4,1.6,0.4,        
        -0.4,1.6,0.4,   //face3

        -0.4,0.9,-0.4,
        0.4,1.6,-0.4,
        0.4,0.9,-0.4,    //

        -0.4,0.9,-0.4,
        0.4,1.6,-0.4,        
        -0.4,1.6,-0.4,   //face4

        0.4,0.9,0.4,
        -0.4,0.9,-0.4,
        -0.4,0.9,0.4,    //

        0.4,0.9,0.4,
        -0.4,0.9,-0.4,
        0.4,0.9,-0.4,    //face5
        

    };
    GLfloat g_vertex_buffer_prism[]={
        0,2,0,
        0.4,1.6,0.4,
        0.4,1.6,-0.4,
        
        0,2,0,
        0.4,1.6,0.4,
        -0.4,1.6,0.4,

        0,2,0,
        -0.4,1.6,-0.4,
        -0.4,1.6,0.4,

        0,2,0,
        -0.4,1.6,-0.4,
        0.4,1.6,-0.4,
    };
    GLfloat g_vertex_buffer_hands[]={

        0.41,0.9,-0.25,
        0.91,0.9,0.25,
        0.91,0.9,-0.25,

        0.41,0.9,-0.25,
        0.91,0.9,0.25,
        0.41,0.9,0.25,

        -0.41,0.9,-0.25,
        -0.91,0.9,0.25,
        -0.91,0.9,-0.25,

        -0.41,0.9,-0.25,
        -0.91,0.9,0.25,
        -0.41,0.9,0.25,

    };
    color = {0,255,0};
    this->missile = Missile(x,y,z,color,0.5,1,0.4);
    this->missile.initx = x;
    this->missile.inity = y;
    this->missile.initz = z;
    this->missile.present = 1;
    this->missile.a = 60;
    this->missile.b = 60;
    color = {0,0,102};
    this->cuboid = create3DObject(GL_TRIANGLES, 8*3, g_vertex_buffer_cuboid, color, GL_FILL);
    this->cube = create3DObject(GL_TRIANGLES, 10*3, g_vertex_buffer_cube, color, GL_FILL);
    color = {255,255,0};
    this->prism = create3DObject(GL_TRIANGLES, 4*3, g_vertex_buffer_prism, color, GL_FILL);
    this->hands = create3DObject(GL_TRIANGLES,4*3,g_vertex_buffer_hands,color,GL_FILL);    
}

void Enemy::draw(glm::mat4 VP) {
    this->enemy_box.x = this->position.x;
    this->enemy_box.y = this->position.y + 0.8;
    this->enemy_box.z = this->position.z;
    this->enemy_box.width = 2;
    this->enemy_box.height = 1.6;
    this->enemy_box.length = 2;
    
    Matrices.model = glm::mat4(1.0f);
    glm::mat4 translate = glm::translate (this->position);    // glTranslatef
    glm::mat4 rotate    = glm::rotate((float) (this->rotation_y * M_PI / 180.0f), glm::vec3(0, 1, 0));
    // No need as coords centered at 0, 0, 0 of cube arouund which we waant to rotate
    // rotate          = rotate * glm::translate(glm::vec3(0, -0.6, 0));
    Matrices.model *= (translate * rotate);
    glm::mat4 MVP = VP * Matrices.model;
    glUniformMatrix4fv(Matrices.MatrixID, 1, GL_FALSE, &MVP[0][0]);
    draw3DObject(this->cube);
    draw3DObject(this->cuboid);
    draw3DObject(this->prism);
    draw3DObject(this->hands);
    this->C1.draw(VP*Matrices.model);
    this->C2.draw(VP*Matrices.model);
    this->C3.draw(VP*Matrices.model);
    this->C4.draw(VP*Matrices.model);
    this->missile.draw(VP);

}

void Enemy::set_position(float x, float y,float z) {
    this->position = glm::vec3(x, y, z);
}

void Enemy::tick1() {
    this->missile.tick();
    if(this->missile.present==0)
    {
        this->missile.present = 1;
        this->missile.position.x = this->position.x;
        this->missile.position.y = this->position.y;
        this->missile.position.z = this->position.z;
        this->missile.initx = this->position.x;
        this->missile.inity = this->position.y;
        this->missile.initz = this->position.z;

    }
    this->rotation_y += 10;
    if(this->r == 1 && this->position.x >= this->init_x + 4.0f)
    {
        this->r = 0;
        this->position.x -= 0.08f;
    }        
    else if(this->r == 1 && this->position.x < this->init_x + 4.0f)
    {
        this->position.x += 0.08f;
    }
    else if(this->r == 0 && this->position.x <= this->init_x - 4.0f )
    {
        this->r = 1;
        this->position.x += 0.08f;
    }
    else if(this->r == 0 && this->position.x > this->init_x - 4.0f)
    {
        this->position.x -= 0.08f;
    }
    else 
    {
    }

    if(this->f == 1 && this->position.z <= this->init_z - 3.0f)
    {
        this->f = 0;
        this->position.z += 0.05f;
    }        
    else if(this->f == 1 && this->position.z > this->init_z - 3.0f)
    {
        this->position.z -= 0.05f;
    }
    else if(this->f == 0 && this->position.z >= this->init_z + 3.0f )
    {
        this->f = 1;
        this->position.z -= 0.05f;
    }
    else if(this->f == 0 && this->position.z < this->init_z + 3.0f)
    {
        this->position.z += 0.05f;
    }
}

void Enemy::tick2() {
    this->rotation_y += 10;
}
