#include "main.h"
#include "timer.h"
#include "plane.h"
#include "ground.h"
#include "obstacle.h"
#include "island.h"
#include "volcano.h"
#include "bomb.h"
#include "circle.h"
#include "circlexy.h"
#include "smoke.h"
#include "enemy.h"
#include "parachute.h"
#include "missile.h"
#include "cannon.h"
#include "compass.h"
#include <sstream>
#include <iostream>

using namespace std;

GLMatrices Matrices;
GLuint     programID;
GLFWwindow *window;

/**************************
* Customizable functions *
**************************/

Plane plane;
Ground ground;
Obstacle obstacle[20];
Island island[10];
Volcano volcano[2];
Bomb bomb;
Smoke smoke; 
Enemy enemy[50];
Enemy spenemy[20];
Parachute parachute[2];
Missile missile;
Cannon cannon;
Compass compass;

int x=0,y=0;
int flag_view;
float x_eye = 0, y_eye = 10,  z_eye = 5;
float x_target = 0,  y_target = 0, z_target = 0;
float screen_zoom = 3, screen_center_x = 0, screen_center_y = 0;
float camera_rotation_angle = 0;
int flag_b;
int flag_s=0;
int flag = 0;
double xpos1=0,ypos1=0;

Timer t60(1.0 / 60);
Timer t600(5.0);
Timer t100(1.0);

/* Render the scene with openGL */
/* Edit this function according to your assignment */
void draw() {
    // clear the color and depth in the frame buffer
    glClear (GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    // use the loaded shader program
    // Don't change unless you know what you are doing
    glUseProgram (programID);

    // Eye - Location of camera. Don't change unless you are sure!!
    glm::vec3 eye ( x_eye, y_eye, z_eye );
    // Target - Where is the camera looking at.  Don't change unless you are sure!!
    glm::vec3 target (x_target, y_target, z_target);
    // Up - Up vector defines tilt of camera.  Don't change unless you are sure!!
    glm::vec3 up (0, 1, 0);

    // Compute Camera matrix (view)
    Matrices.view = glm::lookAt( eye, target, up ); // Rotating Camera for 3D
    // Don't change unless you are sure!!
    // Matrices.view = glm::lookAt(glm::vec3(0, 0, 3), glm::vec3(0, 0, 0), glm::vec3(0, 1, 0)); // Fixed camera for 2D (ortho) in XY plane

    // Compute ViewProject matrix as view/camera might not be changed for this frame (basic scenario)
    // Don't change unless you are sure!!
    glm::mat4 VP = Matrices.projection * Matrices.view;

    // Send our transformation to the currently bound shader, in the "MVP" uniform
    // For each model you render, since the MVP will be different (at least the M part)
    // Don't change unless you are sure!!
    glm::mat4 MVP;  // MVP = Projection * View * Model

    // Scene render
    plane.draw(VP);
    ground.draw(VP);
    for(int i=0;i<20;i++)
        obstacle[i].draw(VP);
    for(int i=0;i<10;i++)
        island[i].draw(VP);
    for(int i=0;i<2;i++)
        volcano[i].draw(VP);
   
    smoke.draw(VP);
    for(int i=0;i<50;i++)
    {  
        if(enemy[i].present)
       enemy[i].draw(VP);
    }
    for(int i=0;i<20;i++)
    {  
        if(spenemy[i].present)
        spenemy[i].draw(VP);
    }
    if(parachute[0].present)
        parachute[0].draw(VP);
    if(parachute[1].present)
        parachute[1].draw(VP);
    if(missile.present)
        missile.draw(VP);
    
    if(cannon.present)
    {    
       cannon.draw(VP);
    }
    if(compass.present)
        compass.draw(VP);
    if(bomb.present)
    {
        bomb.draw(VP);
    }
}

void tick_input(GLFWwindow *window) {
    //movement of plane
    int up          = glfwGetKey(window, GLFW_KEY_G);
    int down        = glfwGetKey(window, GLFW_KEY_H);
    int left_tilt   = glfwGetKey(window, GLFW_KEY_A);
    int right_tilt  = glfwGetKey(window, GLFW_KEY_D);
    int forward     = glfwGetKey(window, GLFW_KEY_W);
    int cw          = glfwGetKey(window, GLFW_KEY_R);
    int acw         = glfwGetKey(window, GLFW_KEY_E);
    int up_tilt     = glfwGetKey(window, GLFW_KEY_J);
    int down_tilt   = glfwGetKey(window,GLFW_KEY_K);    
    int can         = glfwGetKey(window, GLFW_KEY_SPACE);
    int canup       = glfwGetKey(window,GLFW_KEY_UP);
    int candown     = glfwGetKey(window,GLFW_KEY_DOWN);
    int canleft     = glfwGetKey(window,GLFW_KEY_LEFT);
    int canright    = glfwGetKey(window,GLFW_KEY_RIGHT);
    int b_roll      = glfwGetKey(window,GLFW_KEY_L);
    int comp        = glfwGetKey(window,GLFW_KEY_C);

    //camera views
    int pl_view             = glfwGetKey(window, GLFW_KEY_1);
    int top_view            = glfwGetKey(window, GLFW_KEY_2);
    int tower_view          = glfwGetKey(window, GLFW_KEY_3);
    int followcam_view      = glfwGetKey(window, GLFW_KEY_4);
    int hellicopter_view    = glfwGetKey(window, GLFW_KEY_5);

    //movement
    if(up)
    {
        plane.moveup();
    }
    if(down)
    {
        plane.movedown();
    }
    if(left_tilt)
    {
        plane.rotation_z += 1;
        plane.angle_z += 1;
    }
    if(right_tilt)
    {
        plane.rotation_z -= 1;
        plane.angle_z -= 1;       
    }
    if(forward)
    {
        plane.position.z += 0.5*cos((180.0f-plane.angle_y) * M_PI/180.0f);
        plane.position.x += 0.5*cos((90.0f+plane.angle_y) * M_PI/180.0f);

    }
    if(cw)
    {
        plane.rotation_y += 1;
        plane.angle_y += 1;
        cannon.angle_y += 1;
        cannon.rotation_y += 1;
    }
    if(acw)
    {
        plane.rotation_y -= 1;
        plane.angle_y -= 1;
        cannon.angle_y -= 1;
        cannon.rotation_y -= 1;
    }

    if(up_tilt)
    {
        plane.rotation_x += 1;
        plane.angle_x += 1;
        cannon.angle_x += 1;
        cannon.rotation_x += 1;   
    }

    if(down_tilt)
    {
        plane.rotation_x -= 1;
        plane.angle_x -= 1;
        cannon.angle_x -= 1;
        cannon.rotation_x -= 1;   
    }

    //camera views
    if(pl_view)
    {
        flag_view = 1;
    }
    if(top_view)
    {
        flag_view = 2;   
    }
    if(tower_view)
    {
        flag_view = 3;
    }
    if(followcam_view)
    {
        flag_view = 4;
    }
    if(hellicopter_view)
    {
        flag_view = 5;
    }
    
    if(can)
    {
        cannon.present = 1;
        flag_view = 6;          //cannon view
        
    }

    if(canup && flag_view == 6)
    {
        if(cannon.angle_x-plane.angle_x < 8)
        {    cannon.rotation_x+=1;
            cannon.angle_x += 1;
        }
    }
    if(candown && flag_view == 6)
    {
        if(cannon.angle_x-plane.angle_x > -8)
        {    cannon.rotation_x-=1;
            cannon.angle_x -= 1;
        }
    }
    if(canleft && flag_view == 6)
    {
        if(cannon.angle_y-plane.angle_y > -8)
        {    cannon.rotation_y-=1;
            cannon.angle_y -= 1;
        }
    }
    if(canright && flag_view == 6)
    {
        if(cannon.angle_y-plane.angle_y < 8)
        {    cannon.rotation_y+=1;
            cannon.angle_y += 1;
        }
    }
    if(b_roll)
    {   
        plane.rotation_z += 90.0;
        plane.angle_z += 90.0;
        flag_b = 1;
    }
    if(!t100.processTick() && flag_b)
    {
        plane.rotation_z += 90.0;
        plane.angle_z += 90.0;
    }
    else
        flag_b = 0;
    if(comp)
    {
        compass.position.x = plane.position.x - 6;
        compass.position.y = plane.position.y + 0.1;
        compass.position.z = plane.position.z;
        compass.present=1;
    }

}


void tick_elements() {

    if(bomb.present)
    {
        for(int i=0;i<50;i++)
        {
            if(enemy[i].present)
            {
                if(detect_collision(enemy[i].enemy_box,bomb.bomb_box))
                    enemy[i].present = 0;
            }
        }
        for(int i=0;i<20;i++)
        {
            if(spenemy[i].present)
            {
                if(detect_collision(spenemy[i].enemy_box,bomb.bomb_box))
                    spenemy[i].present = 0;
            }
        }
    }
    if(missile.present)
    {
        for(int i=0;i<50;i++)
        {
            if(enemy[i].present && detect_collision(enemy[i].enemy_box,missile.missile_box))
                enemy[i].present = 0;
        }
        for(int i=0;i<20;i++)
        {
            if(spenemy[i].present && detect_collision(spenemy[i].enemy_box,missile.missile_box))
                spenemy[i].present = 0;
        }
        for(int i=0;i<2;i++)
        {
            if(parachute[i].present && detect_collision( parachute[i].parachute_box,missile.missile_box))
                parachute[i].present = 0;
        }
    }
    for(int i=0;i<2;i++)
    {
        if(parachute[i].present)
        {
            if(detect_collision(parachute[i].parachute_box,plane.plane_box))
                plane.health -= 0.05;
        }
    }
    for(int i=0;i<50;i++)
    {
        if(enemy[i].present)
        {
            if(detect_collision(enemy[i].enemy_box,plane.plane_box))
                plane.health -= 0.02;
        }
        if(enemy[i].present)
        {
            if(detect_collision(enemy[i].missile.missile_box,plane.plane_box))
                plane.health -= 0.02;
        }
    }
    for(int i=0;i<20;i++)
    {
        if(spenemy[i].present && detect_collision(spenemy[i].enemy_box,plane.plane_box))
            plane.health -= 0.05;
        if(spenemy[i].present && detect_collision(spenemy[i].missile.missile_box,plane.plane_box))
            plane.health -= 0.05;
    }
    for(int i=0;i<2;i++)
    {
        if(detect_collision(volcano[i].volcano_box,plane.plane_box))
            plane.health =0;
    }

    if(detect_collision(smoke.smoke_box,plane.plane_box))
    {
        flag_s = 1;
        if(flag_s)
        { 
            flag_s=0;   
            plane.points += 5;
        }
    }
    for(int i=0;i<10;i++)
    {
        if(island[i].fuelup == 1)
        {
            if(detect_collision(plane.plane_box,island[i].island_box))
            {
                plane.fuel = 100;
                island[i].fuelup = 0;
            }
        }
    }
    if(detect_collision(plane.plane_box,obstacle[plane.present_target].obstacle_box))
    {
        obstacle[plane.present_target].reached = 1;
        obstacle[plane.present_target].arrowp = 0;
        if(flag == 0)
            plane.present_target++;
        flag = 1;
        obstacle[plane.present_target].arrowp = 1;
    }

    if(parachute[0].present)
        parachute[0].tick();
    if(parachute[1].present)
        parachute[1].tick();
    if(bomb.present)
        bomb.tick();
    if(missile.present)
        missile.tick();
    if(flag_view !=6)
        cannon.present = 0;
    compass.rotation_y = plane.angle_y;
    for(int i=0;i<50;i++)
    {
        if(i%2)
            enemy[i].tick1();
        else
            enemy[i].tick2();
    }
    for(int i=0;i<20;i++)
    {
        spenemy[i].tick2();
    }
    cannon.position.x = plane.position.x ;
    cannon.position.y = plane.position.y ;
    cannon.position.z = plane.position.z ;
    
    if(obstacle[19].reached==1)
    {
        printf("GAME ENDED\n");
        printf("SCORE %d\n",plane.points);
        quit(window);
    }

    if(plane.fuel <=0.0 || plane.position.y <= -2 || plane.health <= 0)
    {
        //printf("helo\n");
        quit(window);
    }


    if(flag_view == 1)
    {
        x_eye = plane.position.x ;
        y_eye = plane.position.y ;
        z_eye = (plane.position.z - 2);
        x_target = x_eye + 5*cos((90.0f+plane.angle_y) * M_PI/180.0f); 
        y_target = y_eye + 5*cos((90.0f-plane.angle_x) * M_PI/180.0f);
        z_target = z_eye + 5*cos((180.0f-plane.angle_y) * M_PI/180.0f) + 5*cos((180.0f-plane.angle_x) * M_PI/180.0f);
    }
    else if(flag_view == 2)
    {
        x_eye = plane.position.x ;
        y_eye = plane.position.y + 30;
        z_eye = plane.position.z + 5;
        x_target = plane.position.x; 
        y_target = plane.position.y ;
        z_target = plane.position.z;
    }
    else if(flag_view == 3)
    {
        x_eye =  plane.position.x - 5;
        y_eye =  plane.position.y + 20;
        z_eye =  plane.position.z;
        x_target = plane.position.x ; 
        y_target = plane.position.y ;
        z_target = plane.position.z ;   
    }
    else if(flag_view == 4)
    {
        x_eye = plane.position.x ;
        y_eye = plane.position.y + 3;
        z_eye = (plane.position.z + 2);
        x_target = x_eye + 5*cos((90.0f+plane.angle_y) * M_PI/180.0f); 
        y_target = y_eye + 5*cos((90.0f-plane.angle_x) * M_PI/180.0f);
        z_target = z_eye + 5*cos((180.0f-plane.angle_y) * M_PI/180.0f) + 5*cos((180.0f-plane.angle_x) * M_PI/180.0f);   
    }
    else if(flag_view == 5)
    {
        glfwGetCursorPos(window, &xpos1, &ypos1);
        //printf("%f %f \n",xpos1,ypos1 );
        x_eye = plane.position.x + (xpos1-500.0f)/50.0;
        z_eye = plane.position.z + (ypos1-500.0f)/50.0;
        y_eye = plane.position.y + 50.0 ;
        x_target = plane.position.x;
        y_target = plane.position.y;
        z_target = plane.position.z;
           
    }
    else if(flag_view == 6)
    {glfwGetCursorPos(window, &xpos1, &ypos1);

        float p = cos((90.0f-cannon.angle_y) * M_PI/180.0f);
        float q = cos((90.0f-cannon.angle_x) * M_PI/180.0f);
        float r = cos((180.0f-cannon.angle_y) * M_PI/180.0f) +cos((180.0f-cannon.angle_x) * M_PI/180.0f) ;
        x_eye = plane.position.x + 2*p; 
        y_eye = plane.position.y + 2*q;
        z_eye = plane.position.z + 2*r ;
        x_target = plane.position.x + 3*p; 
        y_target = plane.position.y + 3*q;
        z_target = plane.position.z + 3*r ;
    
    }

    
}

/* Initialize the OpenGL rendering properties */
/* Add all the models to be created here */
void initGL(GLFWwindow *window, int width, int height) {
    /* Objects should be created before any other gl function and shaders */
    // Create the models

    plane      = Plane(0, 2, 0, COLOR_RED);

    ground     = Ground(0,0,-1.5,COLOR_GREEN);
    
    for(int i=0;i<20;i++)
    {
        int k = rand()%80;
        obstacle[i]   = Obstacle(k-40,0,-200-40*i,COLOR_GREEN);
    }
    obstacle[0].arrowp = 1;

    for(int i=0;i<10;i++)
    {
        int k       = rand()%80;
        int val = 0;
        if(i%5==0)
            val = 1;
        island[i]   = Island(k-40,0,-5-30*i,COLOR_GREEN,val);
    }
    
    volcano[0] = Volcano(50,0,-500,COLOR_BROWN);
    volcano[1] = Volcano(-20,0,-800,COLOR_BROWN);
        
    
    smoke  = Smoke(0,30,-50,COLOR_BLACK);
    
    for(int i=0;i<50;i++)
    {
        int k = rand()%140;
        enemy[i] = Enemy(k-70,0,-5-19*i,COLOR_GREY);
    }

    for(int i=0;i<20;i++)
    {
        spenemy[i] = Enemy(obstacle[i].position.x-0.5,0,obstacle[i].position.z,COLOR_GREY);
    }
    parachute[0] = Parachute(0,35,-60,COLOR_RED);
    parachute[1] = Parachute(0,20,-100,COLOR_GREY);

    cannon = Cannon(0,0,0,COLOR_RED,0.5,7);

    compass = Compass(0,0,0,COLOR_GREY,plane.rotation_y);

    bomb = Bomb(0,0,0,COLOR_BLACK);

    missile = Missile(0,0,0,COLOR_BLACK,0.5,1,0.4);
    // Create and compile our GLSL program from the shaders
    programID = LoadShaders("Sample_GL.vert", "Sample_GL.frag");
    // Get a handle for our "MVP" uniform
    Matrices.MatrixID = glGetUniformLocation(programID, "MVP");


    reshapeWindow (window, width, height);

    // Background color of the scene
    glClearColor (COLOR_BACKGROUND.r / 256.0, COLOR_BACKGROUND.g / 256.0, COLOR_BACKGROUND.b / 256.0, 0.0f); // R, G, B, A
    glClearDepth (1.0f);

    glEnable (GL_DEPTH_TEST);
    glDepthFunc (GL_LEQUAL);

    cout << "VENDOR: " << glGetString(GL_VENDOR) << endl;
    cout << "RENDERER: " << glGetString(GL_RENDERER) << endl;
    cout << "VERSION: " << glGetString(GL_VERSION) << endl;
    cout << "GLSL: " << glGetString(GL_SHADING_LANGUAGE_VERSION) << endl;
}


int main(int argc, char **argv) {
    srand(time(0));
    int width  = 1500;
    int height = 1500;

    window = initGLFW(width, height);

    initGL (window, width, height);

    /* Draw in loop */
    while (!glfwWindowShouldClose(window)) {
        // Process timers

        if(t600.processTick())
        {
            plane.fuel-=1;
            plane.points+= 5;
            flag_s = 1;
            flag = 0;
        }
        if (t60.processTick()) {
            // 60 fps
            string Result;
            stringstream convert;
            convert << plane.points;
            Result = convert.str();
            const char *one = "Points :";
            const char *two = Result.c_str();
            
            const char *three = "   Health :";
            string Result1;
            stringstream convert1;
            convert1 << plane.health;
            Result1 = convert1.str();
            const char *four = Result1.c_str();
            
            stringstream convert2;
            convert2 << plane.fuel;
            string Result2;
            Result2 = convert2.str();
            const char *five = "   Fuel % :";
            const char *six  = Result2.c_str();
            
            stringstream convert3;
            convert3 << plane.position.y ;
            string Result3;
            Result3 = convert3.str();
            const char *seven = "   Altitude :";
            const char *eight  = Result3.c_str();

            stringstream convert4;
            convert4 << plane.speed_y;
            string Result4;
            Result4 = convert4.str();
            const char *nine   = "   Speed :";
            const char *ten    = Result4.c_str();
            
            string total( string(one) + two + string(three) + four +string(five) + six +string(seven) + eight + string(nine) + ten);
            glfwSetWindowTitle(window, total.c_str());
            // OpenGL Draw commands
            draw();
            // Swap Frame Buffer in double buffering
            glfwSwapBuffers(window);

            tick_elements();
            tick_input(window);
        }

        // Poll for Keyboard and mouse events
        glfwPollEvents();
    }

    quit(window);
}

bool detect_collision(bounding_box_t a, bounding_box_t b) {
    return (abs(a.x - b.x) * 2 < (a.width + b.width)) &&
           (abs(a.y - b.y) * 2 < (a.height + b.height)) && 
           (abs(a.z - b.z) * 2 < (a.length + b.length));
}

void reset_screen() {
    float top    = screen_center_y + 4 / screen_zoom;
    float bottom = screen_center_y - 4 / screen_zoom;
    float left   = screen_center_x - 4 / screen_zoom;
    float right  = screen_center_x + 4 / screen_zoom;
    Matrices.projection = glm::perspective(right , left, top, bottom);
}

void bomb_present(){
    if(!bomb.present)
    {
        bomb.present = 1;
        bomb.position.x = plane.position.x;
        bomb.position.y = plane.position.y;
        bomb.position.z = plane.position.z;
        bomb.initx = plane.position.x;
        bomb.inity = plane.position.y;
        bomb.initz = plane.position.z;
        
    }
}
void missile_present(){
    if(!missile.present)
    {
        missile.present = 1;
        missile.position.x = plane.position.x;
        missile.position.y = plane.position.y;
        missile.position.z = plane.position.z;
        missile.initx = plane.position.x;
        missile.inity = plane.position.y;
        missile.initz = plane.position.z;
        missile.a = plane.angle_x;
        missile.b = plane.angle_y;
    }
}

void getpos(double a,double b)
{
    xpos1 = a;
    ypos1 = b;
}