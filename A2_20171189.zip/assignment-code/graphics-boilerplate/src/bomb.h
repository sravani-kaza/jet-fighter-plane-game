#include "main.h"
#include "circle.h"

#ifndef Bomb_H
#define Bomb_H


class Bomb {
public:
    Bomb() {}
    Bomb(float x, float y,float z, color_t color);
    glm::vec3 position;
    Circle C;
    float initx;
    float inity;
    float initz;
    int present;
    float speed_y;
    float rotation;
    void draw(glm::mat4 VP);
    void set_position(float x, float y,float z);
    void tick(); 
    bounding_box_t bomb_box;

};

#endif // Bomb_H
