#include "main.h"
#include "circle.h"

#ifndef PLANE_H
#define PLANE_H


class Plane {
public:
    Plane() {}
    Plane(float x, float y,float z, color_t color);
    glm::vec3 position;
    glm::mat4 rotate;
    float rotation_x;
    float rotation_y;
    float rotation_z;
    float angle_x;
    float angle_y;
    float angle_z;
    void draw(glm::mat4 VP);
    void set_position(float x, float y,float z);
    void tick();
    void moveup();
    void movedown();
    double speed_z;
    double speed_y; 
    int points;
    float fuel;
    float health;
    int present_target;
    bounding_box_t plane_box;
private:
    VAO *body;
    VAO *back;
    VAO *front;
    VAO *side;
};

#endif // PLANE_H
