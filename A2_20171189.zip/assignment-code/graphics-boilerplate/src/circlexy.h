#include "main.h"


#ifndef Circlexy_H
#define Circlexy_H


class Circlexy {
public:
    Circlexy() {}
    Circlexy(float x, float y, float z,color_t color,float r,float length);
    glm::vec3 position;
    float rotation_x;
    float rotation_y;
    float rotation_z;
    void draw(glm::mat4 VP);
    void set_position(float x, float y,float z);
    void tick();
    double speed;

private:
    VAO *object;
};

#endif // Circlexy_H
