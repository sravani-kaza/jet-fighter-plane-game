#include "main.h"


#ifndef Cannon_H
#define Cannon_H


class Cannon {
public:
    Cannon() {}
    Cannon(float x, float y, float z,color_t color,float r,float length);
    glm::vec3 position;
    glm::mat4 rotate;
    float rotation_x;
    float rotation_y;
    float rotation_z;
    float angle_x;
    float angle_y;
    float angle_z;
    int present ;
    void draw(glm::mat4 VP);
    void set_position(float x, float y,float z);
    void tick();

private:
    VAO *object;
};

#endif // Cannon_H
