#include "main.h"
#include "circlexy.h"

#ifndef Smoke_H
#define Smoke_H


class Smoke {
public:
    Smoke() {}
    Smoke(float x, float y,float z, color_t color);
    glm::vec3 position;
    float rotation;
    void draw(glm::mat4 VP);
    void set_position(float x, float y,float z);
    void tick(); 
    Circlexy C1;
    Circlexy C2;
    Circlexy C3;
    bounding_box_t smoke_box;

};

#endif // Smoke_H
