#include "main.h"


#ifndef Missile_H
#define Missile_H


class Missile {
public:
    Missile() {}
    Missile(float x, float y, float z,color_t color,float r,float length,float dist);
    glm::vec3 position;
    float rotation_x;
    float rotation_y;
    float rotation_z;
    float initx;
    float inity;
    float initz; 
    float a;
    float b;
    int present;   
    void draw(glm::mat4 VP);
    void set_position(float x, float y,float z);
    void tick();
    bounding_box_t missile_box;

private:
    VAO *object;
};

#endif // Missile_H
