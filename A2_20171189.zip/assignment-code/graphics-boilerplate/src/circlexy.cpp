#include "circlexy.h"
#include "main.h"

Circlexy::Circlexy(float x, float y, float z,color_t color,float r,float length) {
    this->position = glm::vec3(x, y, z);
    this->rotation_x = 0;
    this->rotation_y = 0;
    this->rotation_z = 0;
    int n=30;
    float th = (2*3.14159)/(float)n;
    GLfloat g_vertex_buffer_data[18*n+1];
    int j = 0;
    int cur = 0;
    for(int i = 0 ; i < 18*n ; i+=18)
    {
        g_vertex_buffer_data[i]  =r*cos(th *(cur));
        g_vertex_buffer_data[i+2]=length;
        g_vertex_buffer_data[i+1]=r*sin(th*(cur));

        g_vertex_buffer_data[i+3]=r*cos(th * cur);
        g_vertex_buffer_data[i+5]=0;
        g_vertex_buffer_data[i+4]=r*sin(th * cur);
        
        g_vertex_buffer_data[i+6]=r*cos(th *(cur+1));
        g_vertex_buffer_data[i+8]=length;
        g_vertex_buffer_data[i+7]=r*sin(th*(cur+1));

        g_vertex_buffer_data[i+9]  =r*cos(th *(cur+1));
        g_vertex_buffer_data[i+11]=0;
        g_vertex_buffer_data[i+10]=r*sin(th*(cur+1));
        
        g_vertex_buffer_data[i+12]=r*cos(th * cur);
        g_vertex_buffer_data[i+14]=0;
        g_vertex_buffer_data[i+13]=r*sin(th * cur);
        
        g_vertex_buffer_data[i+15]=r*cos(th *(cur+1));
        g_vertex_buffer_data[i+17]=length;
        g_vertex_buffer_data[i+16]=r*sin(th*(cur+1));

        cur++;
    }
    // Our vertices. Three consecutive floats give a 3D vertex; Three consecutive vertices give a triangle.
    // A cube has 6 faces with 2 triangles each, so this makes 6*2=12 triangles, and 12*3 vertices

    this->object = create3DObject(GL_TRIANGLES, 2*n*3, g_vertex_buffer_data, color, GL_FILL);
}

void Circlexy::draw(glm::mat4 VP) {
    Matrices.model = glm::mat4(1.0f);
    glm::mat4 translate = glm::translate (this->position);    // glTranslatef
    glm::mat4 rotate    = glm::rotate((float) (this->rotation_z * M_PI / 180.0f), glm::vec3(0, 0, 1));
    //rotate    *= glm::rotate((float) (this->rotation_x * M_PI / 180.0f), glm::vec3(1, 0, 0));
    rotate    *= glm::rotate((float) (this->rotation_x * M_PI / 180.0f), glm::vec3(1, 0, 0));
    rotate    *= glm::rotate((float) (this->rotation_y * M_PI / 180.0f), glm::vec3(0, 1, 0));
    // No need as coords centered at 0, 0, 0 of cube arouund which we waant to rotate
    // rotate          = rotate * glm::translate(glm::vec3(0, -0.6, 0));
    Matrices.model *= (translate * rotate);
    glm::mat4 MVP = VP * Matrices.model;
    glUniformMatrix4fv(Matrices.MatrixID, 1, GL_FALSE, &MVP[0][0]);
    draw3DObject(this->object);
}

void Circlexy::set_position(float x, float y,float z) {
    this->position = glm::vec3(x, y, z);
}

void Circlexy::tick() {
    //   this->rotation += speed;
    // this->position.x -= speed;
    // this->position.y -= speed;
}

