#include "main.h"
#include "circle.h"

#ifndef Volcano_H
#define Volcano_H


class Volcano {
public:
    Volcano() {}
    Volcano(float x, float y,float z, color_t color);
    glm::vec3 position;
    Circle C;
    float rotation;
    void draw(glm::mat4 VP);
    void set_position(float x, float y,float z);
    void tick(); 
    bounding_box_t volcano_box;

private:
    VAO *volcano;
};

#endif // Volcano_H
