#include "plane.h"
#include "main.h"
#include "circle.h"

Plane::Plane(float x, float y, float z,color_t color) {
    this->position = glm::vec3(x, y, z);
    this->angle_x = 0;
    this->angle_y = 0;
    this->angle_z = 0;    
    this->rotation_x = 0;
    this->rotation_y = 0;
    this->rotation_z = 0;
    this->speed_y = 0;
    this->speed_z = 0;
    this->points = 0;
    this->fuel = 100;
    this->health = 1;
    this->present_target = 0;
    glm::mat4 rotate;
    //Our vertices. Three consecutive floats give a 3D vertex; Three consecutive vertices give a triangle.
    // A cube has 6 faces with 2 triangles each, so this makes 6*2=12 triangles, and 12*3 vertices
    GLfloat vertex_buffer_data_body[] = {
            
            0,0,-1.5,
            1,0,-1.5,
            0,0,1.5,          //
            0,0,1.5,
            1,0,1.5,
            1,0,-1.5,          //face1 bottom
            0,1,-1.5,
            1,1,-1.5,
            0,1,1.5,          //
            0,1,1.5,
            1,1,1.5,
            1,1,-1.5,          //face2 top
            1,0,-1.5,
            1,1,-1.5,
            1,0,1.5,          //
            1,0,1.5,
            1,1,1.5,
            1,1,-1.5,          //face3 right
            0,1,-1.5,
            0,0,-1.5,
            0,1,1.5,          //
            0,1,1.5,
            0,0,1.5,
            0,0,-1.5,          //face4 left
            0,0,-1.5,
            1,0,-1.5,
            0,1,-1.5,          //
            0,1,-1.5,
            1,1,-1.5,
            1,0,-1.5,          //face5 front
            0,0,1.5,
            1,0,1.5,
            0,1,1.5,          //
            0,1,1.5,
            1,0,1.5,
            1,1,1.5,          //face6 back 
    }; 
    GLfloat vertex_buffer_data_front[] = {
            

            0.5f,0.5f,-2.25f,
            0,0,-1.5,
            1,0,-1.5,
            0.5f,0.5f,-2.25f,
            1,0,-1.5,
            1,1,1.5,
            0.5f,0.5f,-2.25f,
            1,1,-1.5,
            0,1,-1.5,
            0.5f,0.5f,-2.25f,
            0,1,-1.5,
            0,0,-1.5,
    }; 
    GLfloat vertex_buffer_data_back[] = {
            
            0.5,0,1.5,
            1,0.5,1.5,
            0,0.5,1.5,    //tr1
            0,0.5,1.5,
            0.5,1,1.5,
            1,0.5,1.5
            
    };
    GLfloat vertex_buffer_data_side[] = {
            -2,0,-0.5,
            0,0,-1,
            0,1,-1,
            -2,0,-0.5,
            0,1,-1,
            0,1,-0.5,
            -2,0,-0.5,
            0,1,-0.5,
            0,0,-0.5,
            -2,0,-0.5,
            0,0,-0.5,
            0,0,-1,           //l1
            -1.25,0,1.25,
            0,0,1.25,
            0,0,0.75,
            -1.25,0,1.25,
            0,0,0.75,
            0,1,0.75,
            -1.25,0,1.25,
            0,1,0.75,
            0,1,1.25,
            -1.25,0,1.25,
            0,1,1.25,
            0,0,1.25,           //l2
            3,0,-0.5,
            1,0,-1,
            1,1,-1,
            3,0,-0.5,
            1,1,-1,
            1,1,-0.5,
            3,0,-0.5,
            1,1,-0.5,
            1,0,-0.5,
            3,0,-0.5,
            1,0,-0.5,
            1,0,-1,           //r1
            2.25,0,1.25,
            1,0,1.25,
            1,0,0.75,
            2.25,0,1.25,
            1,0,0.75,
            1,1,0.75,
            2.25,0,1.25,
            1,1,0.75,
            1,1,1.25,
            2.25,0,1.25,
            1,1,1.25,
            1,0,1.25,           //r2

    }; 
    color = {160,160,160};
    this->body = create3DObject(GL_TRIANGLES, 12*3, vertex_buffer_data_body, color, GL_FILL);
    color = { 102,0,0};
    this->front = create3DObject(GL_TRIANGLES, 4*3, vertex_buffer_data_front, color, GL_FILL);
    color = {255,0,0};
    this->back = create3DObject(GL_TRIANGLES, 2*3, vertex_buffer_data_back, color, GL_FILL);
    color = {64,64,64};
    this->side = create3DObject(GL_TRIANGLES, 16*3, vertex_buffer_data_side, color, GL_FILL);
}

void Plane::draw(glm::mat4 VP) {

    this->plane_box.x = this->position.x;
    this->plane_box.y = this->position.y + 0.5;
    this->plane_box.z = this->position.z;
    this->plane_box.width = 2;
    this->plane_box.height = 2;
    this->plane_box.length = 2;


    Matrices.model = glm::mat4(1.0f);
    glm::mat4 translate = glm::translate (this->position);    // glTranslatef
    glm::mat4 rotate_x    = glm::rotate((float) (this->rotation_x * M_PI / 180.0f), glm::vec3(1, 0, 0));
    //rotate    *= glm::rotate((float) (this->rotation_x * M_PI / 180.0f), glm::vec3(1, 0, 0));
    glm::mat4 rotate_y    = glm::rotate((float) (this->rotation_y * M_PI / 180.0f), glm::vec3(0, 1, 0));
    glm::mat4 rotate_z    = glm::rotate((float) (this->rotation_z * M_PI / 180.0f), glm::vec3(0, 0, 1));
    // No need as coords centered at 0, 0, 0 of cube arouund which we waant to rotate
    // rotate          = rotate * glm::translate(glm::vec3(0, -0.6, 0));
    rotate *= rotate_z * rotate_x * rotate_y;  
    Matrices.model *= (translate * rotate);
    glm::mat4 MVP = VP * Matrices.model;
    glUniformMatrix4fv(Matrices.MatrixID, 1, GL_FALSE, &MVP[0][0]);
    draw3DObject(this->body);
    draw3DObject(this->back);
    draw3DObject(this->front);
    draw3DObject(this->side);
    this->rotate = rotate;
    this->rotation_x = 0;
    this->rotation_y = 0;
    this->rotation_z = 0;
}

void Plane::set_position(float x, float y,float z) {
    this->position = glm::vec3(x, y, z);
}

void Plane::tick() {
    //   this->rotation += speed;
    // this->position.x -= speed;
    // this->position.y -= speed;
}


void Plane::movedown(){
    this->speed_y += 0.001 ;
    this->position.y -= this->speed_y;
}

void Plane::moveup(){
    this->speed_y += 0.001;
    this->position.y += this->speed_y;
}