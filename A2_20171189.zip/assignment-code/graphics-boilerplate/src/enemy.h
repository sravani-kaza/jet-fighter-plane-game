#include "main.h"
#include "circlexy.h"
#include "missile.h"


#ifndef Enemy_H
#define Enemy_H


class Enemy {
public:
    Enemy() {}
    Enemy(float x, float y,float z, color_t color);
    float init_x;
    float init_y;
    float init_z;
    int r;
    int f;
    glm::vec3 position;
    float rotation_x;
    float rotation_y;
    float rotation_z;
    Circlexy C1;
    Circlexy C2;
    Circlexy C3;
    Circlexy C4;
    void draw(glm::mat4 VP);
    void set_position(float x, float y,float z);
    void tick1();
    void tick2(); 
    int present ;
    bounding_box_t enemy_box;
    Missile missile;

private:
    VAO *prism;
    VAO *cube;
    VAO *cuboid;
    VAO *hands;
};

#endif // Enemy_H
