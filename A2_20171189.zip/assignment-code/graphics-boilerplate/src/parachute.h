#include "main.h"
#include "circlexz.h"

#ifndef Parachute_H
#define Parachute_H


class Parachute {
public:
    Parachute() {}
    Parachute(float x, float y,float z, color_t color);
    glm::vec3 position;
    float rotation_x;
    float rotation_y;
    float rotation_z;
    float speed_x;
    float speed_z;
    float initx;
    float inity;
    float initz;
    int present; 
    int r;
    int f;   
    Circlexz C[200];
    void draw(glm::mat4 VP);
    void set_position(float x, float y,float z);
    void tick(); 
    bounding_box_t parachute_box;

private:
    VAO *lines;
    VAO *cube;
};

#endif // Parachute_H
