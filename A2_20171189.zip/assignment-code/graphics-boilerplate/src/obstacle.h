#include "main.h"
#include "circle.h"
#include "arrow.h"

#ifndef Obstacle_H
#define Obstacle_H


class Obstacle {
public:
    Obstacle() {}
    Obstacle(float x, float y,float z, color_t color);
    glm::vec3 position;
    float rotation;
    int reached;
    int arrowp;
    Circle C;
    void draw(glm::mat4 VP);
    void set_position(float x, float y,float z);
    void tick(); 
    Arrow arrow;
    bounding_box_t obstacle_box;

private:
    VAO *object;
    VAO *flag;
};

#endif // Obstacle_H
